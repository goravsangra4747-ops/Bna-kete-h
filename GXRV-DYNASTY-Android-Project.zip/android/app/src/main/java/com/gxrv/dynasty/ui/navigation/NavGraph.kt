package com.gxrv.dynasty.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.gxrv.dynasty.ui.screens.*
import com.gxrv.dynasty.ui.theme.*

sealed class Screen(val route: String, val title: String, val icon: ImageVector? = null) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Auth : Screen("auth", "Auth", Icons.Default.AccountCircle)
    object FruitsValues : Screen("fruits", "Values", Icons.Default.LocalFireDepartment)
    object Gamepasses : Screen("gamepasses", "Gamepasses", Icons.Default.ShoppingCart)
    object Calculator : Screen("calculator", "Calc", Icons.Default.Calculate)
    object Listings : Screen("listings", "Trades", Icons.Default.SwapHoriz)
    object NormalStock : Screen("normal_stock", "Stock", Icons.Default.Storefront)
    object MirageStock : Screen("mirage_stock", "Mirage", Icons.Default.Nightlight)
    object CommunityChat : Screen("chat", "Chat", Icons.Default.Forum)
    object ScamReports : Screen("scam_reports", "Shield", Icons.Default.Security)
    object PrivateChat : Screen("private_chat", "DMs", Icons.Default.ChatBubble)
    object TraderProfile : Screen("profile", "Profile", Icons.Default.Person)
    object TradeHistory : Screen("history", "History", Icons.Default.History)
    object AdminPanel : Screen("admin", "Staff", Icons.Default.AdminPanelSettings)
}

val BottomNavItems = listOf(
    Screen.Home,
    Screen.FruitsValues,
    Screen.Calculator,
    Screen.Listings,
    Screen.NormalStock
)

@Composable
fun GxrvNavGraph() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = ObsidianBlack,
                contentColor = TextPrimary,
                tonalElevation = 8.dp,
                modifier = Modifier.background(ObsidianBlack)
            ) {
                BottomNavItems.forEach { screen ->
                    val selected = currentRoute == screen.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(Screen.Home.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = {
                            screen.icon?.let {
                                Icon(
                                    imageVector = it,
                                    contentDescription = screen.title,
                                    tint = if (selected) ElectricBlue else TextSecondary
                                )
                            }
                        },
                        label = {
                            Text(
                                text = screen.title,
                                color = if (selected) ElectricBlue else TextSecondary,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = ElectricBlue.copy(alpha = 0.2f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(navController) }
            composable(Screen.Auth.route) { AuthScreen(navController) }
            composable(Screen.FruitsValues.route) { FruitsValuesScreen(navController) }
            composable(Screen.Gamepasses.route) { GamepassesScreen(navController) }
            composable(Screen.Calculator.route) { TradeCalculatorScreen(navController) }
            composable(Screen.Listings.route) { TradeListingsScreen(navController) }
            composable(Screen.NormalStock.route) { NormalStockScreen(navController) }
            composable(Screen.MirageStock.route) { MirageStockScreen(navController) }
            composable(Screen.CommunityChat.route) { ChatScreen(navController) }
            composable(Screen.PrivateChat.route) { PrivateChatScreen(navController) }
            composable(Screen.ScamReports.route) { ScamReportsScreen(navController) }
            composable(Screen.TraderProfile.route) { TraderProfileScreen(navController) }
            composable(Screen.TradeHistory.route) { TradeHistoryScreen(navController) }
            composable(Screen.AdminPanel.route) { AdminPanelScreen(navController) }
        }
    }
}
