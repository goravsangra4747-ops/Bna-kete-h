package com.gxrv.dynasty.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class Rarity {
    Common, Uncommon, Rare, Legendary, Mythical
}

@Serializable
enum class FruitCategory {
    Natural, Elemental, Beast
}

@Serializable
enum class Trend {
    Up, Stable, Down
}

@Serializable
data class BloxFruit(
    val id: String,
    val name: String,
    val category: FruitCategory,
    val rarity: Rarity,
    val beliPrice: Long,
    val physicalValue: Long,
    val permRobux: Int,
    val permValue: Long,
    val demand: Double,
    val trend: Trend,
    val isMagnet: Boolean = false,
    val awakenedAvailable: Boolean = false,
    val description: String = "",
    val glowColorHex: String = "#00E5FF"
)
