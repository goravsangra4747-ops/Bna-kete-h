package com.gxrv.dynasty.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.gxrv.dynasty.data.model.BloxFruit
import com.gxrv.dynasty.data.model.Rarity
import com.gxrv.dynasty.data.repository.FruitsRepository
import com.gxrv.dynasty.ui.theme.*

@Composable
fun FruitsValuesScreen(navController: NavController) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedRarity by remember { mutableStateOf<Rarity?>(null) }
    var isPhysicalMode by remember { mutableStateOf(true) }

    val fruits = remember(searchQuery, selectedRarity) {
        FruitsRepository.allFruits.filter { fruit ->
            val matchesQuery = fruit.name.contains(searchQuery, ignoreCase = true)
            val matchesRarity = selectedRarity == null || fruit.rarity == selectedRarity
            matchesQuery && matchesRarity
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp)
    ) {
        // Title & Stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Fruits & Values",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Text(
                text = "43 Blox Fruits + Magnet",
                color = ElectricBlue,
                fontSize = 11.sp,
                style = MaterialTheme.typography.labelSmall
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search fruits (e.g. Dragon, Magnet)...", color = TextMuted, fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ElectricBlue) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceDark),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElectricBlue,
                unfocusedBorderColor = BorderDark,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Physical vs Permanent Mode Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(SurfaceDark)
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isPhysicalMode) ElectricBlue else Color.Transparent)
                    .clickable { isPhysicalMode = true }
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Physical Value",
                    color = if (isPhysicalMode) ObsidianBlack else TextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (!isPhysicalMode) ElectricBlue else Color.Transparent)
                    .clickable { isPhysicalMode = false }
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Permanent (Robux)",
                    color = if (!isPhysicalMode) ObsidianBlack else TextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Rarity Filter Horizontal Scroll
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                RarityChip("All", selectedRarity == null) { selectedRarity = null }
            }
            items(Rarity.values()) { rarity ->
                RarityChip(rarity.name, selectedRarity == rarity) { selectedRarity = rarity }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Fruits List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(fruits) { fruit ->
                FruitItemCard(fruit = fruit, isPhysical = isPhysicalMode)
            }
        }
    }
}

@Composable
fun RarityChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) ElectricBlue.copy(alpha = 0.2f) else CardBackground)
            .border(1.dp, if (selected) ElectricBlue else BorderDark, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) ElectricBlue else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
fun FruitItemCard(fruit: BloxFruit, isPhysical: Boolean) {
    val displayValue = if (isPhysical) {
        if (fruit.physicalValue >= 1_000_000) "${fruit.physicalValue / 1_000_000}M" else "${fruit.physicalValue / 1_000}K"
    } else {
        "${fruit.permValue / 1_000_000}M (${fruit.permRobux} R$)"
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardBackground)
            .border(
                1.dp,
                if (fruit.isMagnet) ElectricBlue.copy(alpha = 0.6f) else BorderDark,
                RoundedCornerShape(14.dp)
            )
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = fruit.name,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    if (fruit.isMagnet) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "MAGNET",
                            color = ElectricBlue,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SurfaceDark)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "${fruit.rarity} · ${fruit.category} · ${fruit.beliPrice / 1000}k Beli",
                    color = TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = displayValue,
                    color = ProfitGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "★ ${fruit.demand}/10 Demand",
                    color = DemandAmber,
                    fontSize = 10.sp
                )
            }
        }
    }
}
