package com.gxrv.dynasty.data.repository

import com.gxrv.dynasty.data.model.*

/**
 * Repository containing the complete roster of all 43 Blox Fruits + Magnet
 * and their baseline physical & permanent trading values.
 */
object FruitsRepository {
    val allFruits: List<BloxFruit> = listOf(
        // COMMON (7)
        BloxFruit("rocket", "Rocket", FruitCategory.Natural, Rarity.Common, 5000L, 50000L, 50, 500000L, 1.5, Trend.Stable, false, false, "Launches explosive rockets."),
        BloxFruit("spin", "Spin", FruitCategory.Natural, Rarity.Common, 7500L, 60000L, 75, 600000L, 1.0, Trend.Down, false, false, "Spins like helicopter propellers."),
        BloxFruit("blade", "Blade (Chop)", FruitCategory.Natural, Rarity.Common, 30000L, 120000L, 100, 900000L, 2.5, Trend.Stable, false, false, "Complete immunity to sword slashes."),
        BloxFruit("spring", "Spring", FruitCategory.Natural, Rarity.Common, 60000L, 150000L, 180, 1200000L, 1.2, Trend.Down, false, false, "Coiled leaps across battlefields."),
        BloxFruit("bomb", "Bomb", FruitCategory.Natural, Rarity.Common, 80000L, 200000L, 220, 1500000L, 2.0, Trend.Stable, false, false, "Large area explosive detonations."),
        BloxFruit("smoke", "Smoke", FruitCategory.Elemental, Rarity.Common, 100000L, 250000L, 250, 1800000L, 2.2, Trend.Stable, false, false, "Elemental logia evasion and cloud flight."),
        BloxFruit("spike", "Spike", FruitCategory.Natural, Rarity.Common, 180000L, 300000L, 380, 2000000L, 1.8, Trend.Down, false, false, "Thorn impalements."),

        // UNCOMMON (6)
        BloxFruit("flame", "Flame", FruitCategory.Elemental, Rarity.Uncommon, 250000L, 800000L, 550, 4500000L, 4.8, Trend.Up, false, true, "Awakened fire columns."),
        BloxFruit("falcon", "Falcon", FruitCategory.Beast, Rarity.Uncommon, 300000L, 500000L, 650, 3500000L, 2.0, Trend.Down, false, false, "Winged predator with feather volleys."),
        BloxFruit("ice", "Ice", FruitCategory.Elemental, Rarity.Uncommon, 350000L, 1200000L, 750, 6000000L, 6.5, Trend.Up, false, true, "Walks on sea water. Awakened stuns."),
        BloxFruit("sand", "Sand", FruitCategory.Elemental, Rarity.Uncommon, 420000L, 900000L, 850, 5000000L, 4.2, Trend.Stable, false, true, "Desiccating sand vortexes."),
        BloxFruit("dark", "Dark", FruitCategory.Elemental, Rarity.Uncommon, 500000L, 1400000L, 950, 7000000L, 6.0, Trend.Up, false, true, "Black hole stuns for sword combos."),
        BloxFruit("diamond", "Diamond", FruitCategory.Natural, Rarity.Uncommon, 600000L, 700000L, 1000, 5500000L, 3.0, Trend.Down, false, false, "25% passive defense hardening."),

        // RARE (5)
        BloxFruit("light", "Light", FruitCategory.Elemental, Rarity.Rare, 650000L, 2500000L, 1100, 12000000L, 7.8, Trend.Up, false, true, "Fastest flight speed and awakened laser bursts."),
        BloxFruit("rubber", "Rubber", FruitCategory.Natural, Rarity.Rare, 750000L, 1800000L, 1200, 9000000L, 5.5, Trend.Stable, false, false, "Immunity to lightning."),
        BloxFruit("barrier", "Barrier", FruitCategory.Natural, Rarity.Rare, 800000L, 1200000L, 1250, 8000000L, 3.2, Trend.Down, false, false, "Summons energy shielding."),
        BloxFruit("ghost", "Ghost", FruitCategory.Natural, Rarity.Rare, 940000L, 2200000L, 1275, 10000000L, 6.0, Trend.Stable, false, false, "Automatic resurrection on death."),
        BloxFruit("magma", "Magma", FruitCategory.Elemental, Rarity.Rare, 960000L, 3500000L, 1300, 15000000L, 8.5, Trend.Up, false, true, "Highest total damage for Sea Beasts."),

        // LEGENDARY (10)
        BloxFruit("quake", "Quake", FruitCategory.Natural, Rarity.Legendary, 1000000L, 3000000L, 1500, 14000000L, 5.0, Trend.Stable, false, true, "Seismic tsunamis."),
        BloxFruit("buddha", "Buddha", FruitCategory.Beast, Rarity.Legendary, 1200000L, 10000000L, 1650, 45000000L, 9.8, Trend.Up, false, true, "#1 grinding fruit. 50% damage reduction."),
        BloxFruit("love", "Love", FruitCategory.Natural, Rarity.Legendary, 1300000L, 3200000L, 1700, 16000000L, 5.5, Trend.Stable, false, false, "Cupid ride and charms."),
        BloxFruit("spider", "Spider", FruitCategory.Natural, Rarity.Legendary, 1500000L, 3000000L, 1800, 15000000L, 4.8, Trend.Down, false, true, "Razor strings."),
        BloxFruit("sound", "Sound", FruitCategory.Natural, Rarity.Legendary, 1700000L, 5000000L, 1900, 22000000L, 6.8, Trend.Stable, false, false, "Tempo boosts and acoustic blasts."),
        BloxFruit("phoenix", "Phoenix", FruitCategory.Beast, Rarity.Legendary, 1800000L, 4000000L, 2000, 20000000L, 5.8, Trend.Up, false, true, "Blue flame heals."),
        BloxFruit("portal", "Portal", FruitCategory.Natural, Rarity.Legendary, 1900000L, 12000000L, 2000, 50000000L, 9.7, Trend.Up, false, false, "Instant island teleports."),
        BloxFruit("rumble", "Rumble", FruitCategory.Elemental, Rarity.Legendary, 2100000L, 8000000L, 2100, 35000000L, 8.8, Trend.Up, false, true, "Thunder god dashes and stuns."),
        BloxFruit("pain", "Pain", FruitCategory.Natural, Rarity.Legendary, 2300000L, 3500000L, 2200, 18000000L, 4.5, Trend.Down, false, false, "Paw repulsions."),
        BloxFruit("blizzard", "Blizzard", FruitCategory.Elemental, Rarity.Legendary, 2400000L, 6000000L, 2250, 26000000L, 7.2, Trend.Stable, false, false, "Swirling snow tornadoes."),

        // MYTHICAL (15)
        BloxFruit("gravity", "Gravity", FruitCategory.Natural, Rarity.Mythical, 2500000L, 4000000L, 2300, 20000000L, 4.0, Trend.Down, false, false, "Meteor summons."),
        BloxFruit("mammoth", "Mammoth", FruitCategory.Beast, Rarity.Mythical, 2700000L, 12500000L, 2350, 55000000L, 7.9, Trend.Stable, false, false, "Ancient mammoth charge."),
        BloxFruit("trex", "T-Rex", FruitCategory.Beast, Rarity.Mythical, 2700000L, 20000000L, 2350, 70000000L, 8.6, Trend.Stable, false, false, "Apex carnivore tail whips."),
        BloxFruit("dough", "Dough", FruitCategory.Elemental, Rarity.Mythical, 2800000L, 25000000L, 2400, 90000000L, 9.6, Trend.Up, false, true, "Awakened infinite combo master."),
        BloxFruit("shadow", "Shadow", FruitCategory.Natural, Rarity.Mythical, 2900000L, 8000000L, 2425, 38000000L, 6.9, Trend.Stable, false, false, "Life-stealing shadow bats."),
        BloxFruit("venom", "Venom", FruitCategory.Natural, Rarity.Mythical, 3000000L, 10000000L, 2450, 45000000L, 7.5, Trend.Stable, false, false, "Three-headed toxic hydra."),
        BloxFruit("control", "Control", FruitCategory.Natural, Rarity.Mythical, 3200000L, 9000000L, 2500, 42000000L, 7.0, Trend.Up, false, false, "Telekinetic ROOM boundary."),
        BloxFruit("spirit", "Spirit", FruitCategory.Natural, Rarity.Mythical, 3400000L, 11000000L, 2550, 48000000L, 7.3, Trend.Stable, false, false, "Wrath and calm homie spirits."),
        BloxFruit("dragon", "Dragon (East / Rework)", FruitCategory.Beast, Rarity.Mythical, 3500000L, 180000000L, 5000, 350000000L, 10.0, Trend.Up, false, false, "Top market jewel."),
        BloxFruit("leopard", "Leopard", FruitCategory.Beast, Rarity.Mythical, 5000000L, 40000000L, 3000, 140000000L, 9.0, Trend.Stable, false, false, "Extreme speed hybrid."),
        BloxFruit("kitsune", "Kitsune", FruitCategory.Beast, Rarity.Mythical, 8000000L, 130000000L, 4000, 280000000L, 9.9, Trend.Up, false, false, "Nine-tailed fox with spirit blue flames."),
        BloxFruit("gas", "Gas", FruitCategory.Elemental, Rarity.Mythical, 3200000L, 45000000L, 2600, 120000000L, 9.2, Trend.Up, false, false, "Volatile gas detonations."),
        BloxFruit("yeti", "Yeti", FruitCategory.Beast, Rarity.Mythical, 4000000L, 60000000L, 2800, 160000000L, 9.3, Trend.Up, false, false, "Sub-zero frost titan armor."),
        BloxFruit("tiger", "Tiger (Beast Claw)", FruitCategory.Beast, Rarity.Mythical, 4200000L, 75000000L, 2900, 180000000L, 9.4, Trend.Up, false, false, "Shield-shredding razor pounce."),
        BloxFruit("celestial", "Celestial", FruitCategory.Elemental, Rarity.Mythical, 5000000L, 110000000L, 3500, 240000000L, 9.8, Trend.Up, false, true, "Astral stellar radiance."),

        // SPECIAL REQUESTED: MAGNET (Fruit #44)
        BloxFruit("magnet", "Magnet", FruitCategory.Natural, Rarity.Mythical, 3800000L, 55000000L, 2750, 150000000L, 9.5, Trend.Up, true, true, "Electromagnetic attraction & repulsion junk vortex.")
    )

    fun getFruitById(id: String): BloxFruit? = allFruits.find { it.id == id }
}
