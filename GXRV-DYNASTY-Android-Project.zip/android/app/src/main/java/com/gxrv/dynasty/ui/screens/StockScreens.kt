package com.gxrv.dynasty.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.gxrv.dynasty.data.model.StockItem
import com.gxrv.dynasty.ui.theme.*

@Composable
fun NormalStockScreen(navController: NavController) {
    val normalStock = remember {
        listOf(
            StockItem("s1", "rocket", "Rocket", "normal", true, 5000L, 50, 100.0, "Today"),
            StockItem("s2", "flame", "Flame", "normal", true, 250000L, 550, 65.0, "Today"),
            StockItem("s3", "light", "Light", "normal", true, 650000L, 1100, 42.0, "Today"),
            StockItem("s4", "buddha", "Buddha", "normal", true, 1200000L, 1650, 18.0, "Today"),
            StockItem("s5", "portal", "Portal", "normal", false, 1900000L, 2000, 12.0, "Yesterday"),
            StockItem("s6", "dough", "Dough", "normal", false, 2800000L, 2400, 4.5, "Yesterday")
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Blox Fruits Normal Stock", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("In-game dealer resets every 4 hours", color = TextSecondary, fontSize = 12.sp)

            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(SurfaceDark)
                    .border(1.dp, BorderAccent, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Next Dealer Reset:", color = TextSecondary, fontSize = 12.sp)
                    Text("02:34:18", color = ElectricBlue, fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
            }
        }

        items(normalStock) { item ->
            StockItemCard(item = item)
        }
    }
}

@Composable
fun MirageStockScreen(navController: NavController) {
    val mirageStock = remember {
        listOf(
            StockItem("ms1", "buddha", "Buddha", "mirage", true, 1200000L, 1650, 60.0, "Active"),
            StockItem("ms2", "portal", "Portal", "mirage", true, 1900000L, 2000, 45.0, "Active"),
            StockItem("ms3", "dragon", "Dragon (East / Rework)", "mirage", true, 3500000L, 5000, 8.0, "Active"),
            StockItem("ms4", "magnet", "Magnet", "mirage", true, 3800000L, 2750, 12.0, "Active"),
            StockItem("ms5", "kitsune", "Kitsune", "mirage", false, 8000000L, 4000, 6.5, "Active")
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Mirage Island Dealer Stock", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Third Sea advanced dealer · Resonates on Full Moon", color = MiragePurple, fontSize = 12.sp)
        }

        items(mirageStock) { item ->
            StockItemCard(item = item)
        }
    }
}

@Composable
fun StockItemCard(item: StockItem) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardBackground)
            .border(
                1.dp,
                if (item.inStock) ProfitGreen.copy(alpha = 0.5f) else BorderDark,
                RoundedCornerShape(14.dp)
            )
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(item.fruitName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("${item.priceBeli / 1000}k Beli · ${item.priceRobux} R$ · ${item.chancePercent}% spawn", color = TextMuted, fontSize = 11.sp)
            }
            Text(
                if (item.inStock) "IN STOCK" else "OUT OF STOCK",
                color = if (item.inStock) ProfitGreen else LossRed,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}
