package com.gxrv.dynasty

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.gxrv.dynasty.ui.navigation.GxrvNavGraph
import com.gxrv.dynasty.ui.theme.GxrvDynastyTheme

/**
 * GXRV DYNASTY - Blox Fruits Native Android Hub
 * Built with Kotlin & Jetpack Compose
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GxrvDynastyTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = GxrvDynastyTheme.colors.background
                ) {
                    GxrvNavGraph()
                }
            }
        }
    }
}
