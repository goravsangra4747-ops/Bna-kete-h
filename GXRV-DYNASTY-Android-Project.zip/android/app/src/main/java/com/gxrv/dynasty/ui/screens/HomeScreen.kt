package com.gxrv.dynasty.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.gxrv.dynasty.ui.navigation.Screen
import com.gxrv.dynasty.ui.theme.*

@Composable
fun HomeScreen(navController: NavController) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceDark)
                    .border(1.dp, BorderAccent, RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "GXRV",
                            color = ElectricBlue,
                            fontWeight = FontWeight.Black,
                            fontSize = 24.sp
                        )
                        Text(
                            text = "DYNASTY",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                    Text(
                        text = "Native Blox Fruits Trading Companion & Stock Terminal",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(ProfitGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Dealer: Live Online", color = TextSecondary, fontSize = 11.sp)
                        }
                        Text(
                            text = "All 43 Fruits + Magnet",
                            color = ElectricBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Quick Navigation Grid
        item {
            Text(
                text = "Trading Hub Features",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HomeFeatureCard(
                    title = "Trade Calc",
                    subtitle = "40% Beli check",
                    color = ElectricBlue,
                    modifier = Modifier.weight(1f)
                ) {
                    navController.navigate(Screen.Calculator.route)
                }
                HomeFeatureCard(
                    title = "Values (44)",
                    subtitle = "Physical & Perm",
                    color = DemandAmber,
                    modifier = Modifier.weight(1f)
                ) {
                    navController.navigate(Screen.FruitsValues.route)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HomeFeatureCard(
                    title = "Listings",
                    subtitle = "Market offers",
                    color = NeonCyan,
                    modifier = Modifier.weight(1f)
                ) {
                    navController.navigate(Screen.Listings.route)
                }
                HomeFeatureCard(
                    title = "Scam Shield",
                    subtitle = "Blacklist & proof",
                    color = LossRed,
                    modifier = Modifier.weight(1f)
                ) {
                    navController.navigate(Screen.ScamReports.route)
                }
            }
        }

        // High Demand Spotlights
        item {
            Text(
                text = "High Demand Market Fruits",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FruitSpotlightRow("Dragon (East / Rework)", "180M Val", "10.0/10 Demand")
                FruitSpotlightRow("Kitsune", "130M Val", "9.9/10 Demand")
                FruitSpotlightRow("Magnet (Custom / Update)", "55M Val", "9.5/10 Demand")
                FruitSpotlightRow("Dough (Awakened)", "25M Val", "9.6/10 Demand")
            }
        }
    }
}

@Composable
fun HomeFeatureCard(title: String, subtitle: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CardBackground)
            .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column {
            Text(title, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun FruitSpotlightRow(name: String, value: String, demand: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBackground)
            .border(1.dp, BorderDark, RoundedCornerShape(12.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(value, color = ProfitGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(demand, color = DemandAmber, fontSize = 11.sp)
        }
    }
}
