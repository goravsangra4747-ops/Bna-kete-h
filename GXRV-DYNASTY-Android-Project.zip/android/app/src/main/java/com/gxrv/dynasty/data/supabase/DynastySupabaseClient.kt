package com.gxrv.dynasty.data.supabase

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime

/**
 * Supabase client singleton for GXRV Dynasty Android native app.
 * Utilizes Row Level Security (RLS) with the public anonymous key.
 * Service role keys are NEVER embedded in client builds.
 */
object DynastySupabaseClient {
    // Configured via BuildConfig or dynamic in-app settings
    private var clientInstance: SupabaseClient? = null

    fun initialize(supabaseUrl: String, supabaseAnonKey: String): SupabaseClient {
        val client = createSupabaseClient(
            supabaseUrl = supabaseUrl,
            supabaseKey = supabaseAnonKey
        ) {
            install(Auth)
            install(Postgrest)
            install(Realtime)
        }
        clientInstance = client
        return client
    }

    fun getClient(): SupabaseClient? = clientInstance
}
