package com.gxrv.dynasty.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.gxrv.dynasty.data.model.TradeItem
import com.gxrv.dynasty.data.model.TradeListing
import com.gxrv.dynasty.ui.theme.*

@Composable
fun TradeListingsScreen(navController: NavController) {
    val sampleListings = remember {
        listOf(
            TradeListing(
                id = "l1",
                userId = "u1",
                userName = "GXRV Dynasty [Owner]",
                traderId = "GXRV-0001-K",
                robloxUsername = "GXRV_DynastyKing",
                offering = listOf(TradeItem("dragon", "Dragon (East / Rework)"), TradeItem("dough", "Dough")),
                lookingFor = listOf(TradeItem("fruit_notifier", "Fruit Notifier", isGamepass = true)),
                notes = "Fast trade at Cafe Second Sea or Mansion.",
                verifiedTrader = true
            ),
            TradeListing(
                id = "l2",
                userId = "u2",
                userName = "Valkyrie [Admin]",
                traderId = "GXRV-0024-A",
                robloxUsername = "ValkyrieSword_Blox",
                offering = listOf(TradeItem("magnet", "Magnet"), TradeItem("kitsune", "Kitsune")),
                lookingFor = listOf(TradeItem("dark_blade", "Dark Blade", isGamepass = true)),
                notes = "Magnet has extreme PvP attraction mechanics.",
                verifiedTrader = true
            )
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Live Trade Listings",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    "${sampleListings.size} Active",
                    color = ElectricBlue,
                    fontSize = 11.sp,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Text(
                "Player-to-player market exchange. Tap to view or message counterparty.",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        items(sampleListings) { listing ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CardBackground)
                    .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(listing.userName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("@${listing.robloxUsername} · ${listing.traderId}", color = TextMuted, fontSize = 11.sp)
                        }
                        if (listing.verifiedTrader) {
                            Text(
                                "VERIFIED",
                                color = ElectricBlue,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SurfaceDark)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("OFFERING", color = ElectricBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            listing.offering.forEach { item ->
                                Text("• ${item.name}", color = TextPrimary, fontSize = 12.sp)
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("LOOKING FOR", color = MiragePurple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            listing.lookingFor.forEach { item ->
                                Text("• ${item.name}", color = TextPrimary, fontSize = 12.sp)
                            }
                        }
                    }

                    if (listing.notes.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("\"${listing.notes}\"", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
