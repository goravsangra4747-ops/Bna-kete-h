package com.gxrv.dynasty.ui.theme

import androidx.compose.ui.graphics.Color

val ElectricBlue = Color(0xFF00E5FF)
val ElectricBlueDim = Color(0xFF00B4D8)
val NeonCyan = Color(0xFF38BDF8)
val ObsidianBlack = Color(0xFF080B11)
val SurfaceDark = Color(0xFF0F1523)
val CardBackground = Color(0xFF0B0F19)
val BorderDark = Color(0xFF1E293B)
val BorderAccent = Color(0x3300E5FF)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val ProfitGreen = Color(0xFF10B981)
val LossRed = Color(0xFFF43F5E)
val DemandAmber = Color(0xFFF59E0B)
val MiragePurple = Color(0xFFA855F7)
