package com.gxrv.dynasty.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.gxrv.dynasty.data.model.BloxFruit
import com.gxrv.dynasty.data.repository.FruitsRepository
import com.gxrv.dynasty.ui.theme.*
import kotlin.math.abs
import kotlin.math.max

@Composable
fun TradeCalculatorScreen(navController: NavController) {
    var sideA by remember { mutableStateOf(listOf(FruitsRepository.allFruits.find { it.id == "dragon" }!!)) }
    var sideB by remember {
        mutableStateOf(
            listOf(
                FruitsRepository.allFruits.find { it.id == "kitsune" }!!,
                FruitsRepository.allFruits.find { it.id == "dough" }!!
            )
        )
    }

    val totalValueA = sideA.sumOf { it.physicalValue }
    val totalValueB = sideB.sumOf { it.physicalValue }
    val totalBeliA = sideA.sumOf { it.beliPrice }
    val totalBeliB = sideB.sumOf { it.beliPrice }

    val delta = totalValueB - totalValueA

    // Blox Fruits in-game 40% threshold check
    val isBeliLimitExceeded = remember(totalBeliA, totalBeliB) {
        if (totalBeliA == 0L || totalBeliB == 0L) false
        else (abs(totalBeliA - totalBeliB).toDouble() / max(totalBeliA, totalBeliB)) > 0.4
    }

    val verdict = when {
        delta > 15_000_000L -> "BIG WIN"
        delta > 2_000_000L -> "WIN"
        abs(delta) <= 2_000_000L -> "FAIR TRADE"
        delta < -15_000_000L -> "HUGE LOSS"
        else -> "LOSS"
    }

    val verdictColor = when (verdict) {
        "BIG WIN", "WIN" -> ProfitGreen
        "FAIR TRADE" -> ElectricBlue
        else -> LossRed
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "Trade Calculator",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Text(
                "Blox Fruits 40% Beli difference limiter & market value parity check",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        // Verdict Result Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SurfaceDark)
                    .border(1.dp, verdictColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "VERDICT: $verdict",
                            color = verdictColor,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "${if (delta >= 0) "+" else ""}${delta / 1_000_000}M Delta",
                            color = verdictColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    if (isBeliLimitExceeded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "⚠ 40% Beli Limit Exceeded: In-game Blox Fruits table will reject this trade until balanced.",
                            color = LossRed,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Side A: You Give
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CardBackground)
                    .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("You Give (${sideA.size}/5)", color = ElectricBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Total: ${totalValueA / 1_000_000}M Val", color = ElectricBlue, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(8.dp))
                sideA.forEach { fruit ->
                    TradeSlotRow(fruit = fruit, onRemove = { sideA = sideA.filter { it.id != fruit.id } })
                }
            }
        }

        // Side B: They Give
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CardBackground)
                    .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("They Give (${sideB.size}/5)", color = MiragePurple, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Total: ${totalValueB / 1_000_000}M Val", color = MiragePurple, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(8.dp))
                sideB.forEach { fruit ->
                    TradeSlotRow(fruit = fruit, onRemove = { sideB = sideB.filter { it.id != fruit.id } })
                }
            }
        }
    }
}

@Composable
fun TradeSlotRow(fruit: BloxFruit, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceDark)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(fruit.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("${fruit.physicalValue / 1_000_000}M Val · ${fruit.beliPrice / 1_000}k Beli", color = TextMuted, fontSize = 10.sp)
        }
        Text(
            "✕",
            color = LossRed,
            fontSize = 12.sp,
            modifier = Modifier.clickable { onRemove() }
        )
    }
}
