package com.gxrv.dynasty.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.gxrv.dynasty.data.model.ChatMessage
import com.gxrv.dynasty.data.model.ScamReport
import com.gxrv.dynasty.ui.theme.*

@Composable
fun ChatScreen(navController: NavController) {
    val messages = remember {
        listOf(
            ChatMessage("1", "trading", "u1", "GXRV Dynasty [Owner]", "owner", "OWNER", "Welcome to the dynasty! Check Trade Calculator before finalizing.", "10:00 AM", true),
            ChatMessage("2", "trading", "u2", "Valkyrie [Admin]", "admin", "ADMIN", "Mirage dealer has spawned with Dragon and Magnet in stock!", "10:14 AM"),
            ChatMessage("3", "trading", "u3", "SeaRider_Trades", "trader", "TRADER", "Offering T-Rex + Mammoth for Dough + Portal. Cafe table 2.", "10:22 AM")
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Community Trading Channels & DMs", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("#trading · #price-checks · #general", color = ElectricBlue, fontSize = 12.sp)
        }

        items(messages) { msg ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardBackground)
                    .border(1.dp, if (msg.isPinned) ElectricBlue.copy(alpha = 0.4f) else BorderDark, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(msg.senderName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                msg.senderBadge,
                                color = ElectricBlue,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SurfaceDark)
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                        Text(msg.timestamp, color = TextMuted, fontSize = 10.sp)
                    }
                    Text(msg.content, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
fun ScamReportsScreen(navController: NavController) {
    val reports = remember {
        listOf(
            ScamReport("s1", "RobloxHacker_FakeVIP99", "u3", "SeaRider", "Phishing Link", "Sent fake VIP server URL to steal Blox Fruits account.", "https://proof.example/1", "verified_scammer", "Confirmed IP grabber.", "Sentinel [Mod]"),
            ScamReport("s2", "TrustTrader_FreePerms", "u4", "Aero", "Trust Trade", "Promised +1 Fruit Storage then left after receiving Leopard.", "https://proof.example/2", "verified_scammer", "Confirmed video proof.", "Valkyrie [Admin]")
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Community Scam Shield & Blacklist", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Verified scammer directory with screenshot proof records", color = LossRed, fontSize = 12.sp)
        }

        items(reports) { report ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(CardBackground)
                    .border(1.dp, LossRed.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("@${report.reportedUsername}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("VERIFIED SCAMMER", color = LossRed, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                    Text("Type: ${report.scamType} · Reported by @${report.reporterUsername}", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(report.description, color = TextSecondary, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun PrivateChatScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Private Trader Chat (DMs)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Encrypted 1-on-1 direct messaging between traders", color = ElectricBlue, fontSize = 12.sp)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(SurfaceDark)
                .border(1.dp, BorderDark, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Chatting with: @ValkyrieSword_Blox [Admin]", color = ElectricBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Valkyrie: Hey, verified 2 scam reports and updated Dragon East Rework.", color = TextSecondary, fontSize = 12.sp)
                Text("You: Thanks! Ready to trade at Cafe Second Sea.", color = ProfitGreen, fontSize = 12.sp)
            }
        }
    }
}

