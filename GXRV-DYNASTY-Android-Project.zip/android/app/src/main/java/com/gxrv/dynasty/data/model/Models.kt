package com.gxrv.dynasty.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Gamepass(
    val id: String,
    val name: String,
    val robuxPrice: Int,
    val tradeValue: Long,
    val demand: Double,
    val trend: Trend,
    val description: String
)

@Serializable
data class TradeItem(
    val id: String,
    val name: String,
    val isGamepass: Boolean = false,
    val isPermanent: Boolean = false
)

@Serializable
data class TradeListing(
    val id: String,
    val userId: String,
    val userName: String,
    val traderId: String,
    val robloxUsername: String,
    val offering: List<TradeItem>,
    val lookingFor: List<TradeItem>,
    val notes: String = "",
    val status: String = "active",
    val createdAt: String = "Just now",
    val verifiedTrader: Boolean = false
)

@Serializable
data class StockItem(
    val id: String,
    val fruitId: String,
    val fruitName: String,
    val stockType: String, // "normal" or "mirage"
    val inStock: Boolean,
    val priceBeli: Long,
    val priceRobux: Int,
    val chancePercent: Double,
    val lastRestocked: String
)

@Serializable
data class ScamReport(
    val id: String,
    val reportedUsername: String,
    val reporterId: String,
    val reporterUsername: String,
    val scamType: String,
    val description: String,
    val proofUrl: String,
    val status: String = "pending", // "pending", "verified_scammer", "dismissed"
    val evidenceNotes: String? = null,
    val reviewedBy: String? = null,
    val createdAt: String = "Today"
)

@Serializable
data class TraderProfile(
    val id: String,
    val userId: String,
    val traderId: String,
    val robloxUsername: String,
    val displayName: String,
    val role: String = "trader", // "owner", "admin", "moderator", "junior_mod", "trader"
    val bio: String = "",
    val reputation: Int = 95,
    val completedTrades: Int = 0,
    val vouchesCount: Int = 0,
    val vouches: List<String> = emptyList(),
    val badges: List<String> = emptyList(),
    val joinedDate: String = "2026"
)

@Serializable
data class ChatMessage(
    val id: String,
    val channel: String = "trading",
    val senderId: String,
    val senderName: String,
    val senderRole: String,
    val senderBadge: String,
    val content: String,
    val timestamp: String,
    val isPinned: Boolean = false
)
