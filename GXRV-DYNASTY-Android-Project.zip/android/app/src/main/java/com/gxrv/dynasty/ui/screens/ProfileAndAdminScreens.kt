package com.gxrv.dynasty.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.gxrv.dynasty.ui.theme.*

@Composable
fun AuthScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("GXRV DYNASTY", color = ElectricBlue, fontWeight = FontWeight.Black, fontSize = 24.sp)
        Text("Trader Authentication & Supabase GoTrue", color = TextSecondary, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(20.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardBackground)
                .border(1.dp, BorderDark, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Role-Based Access (RBAC)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Supports Owner, Admin, Moderator, Junior Mod, and Verified Trader tiers.", color = TextMuted, fontSize = 12.sp)
                Text("Trader ID Generation: GXRV-XXXX-T", color = ElectricBlue, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun GamepassesScreen(navController: NavController) {
    val passes = listOf(
        "Dark Blade (Yoru)" to "75M Val · 1200 R$",
        "Fruit Notifier" to "160M Val · 2700 R$",
        "+1 Fruit Storage" to "28M Val · 400 R$",
        "2x Money" to "30M Val · 450 R$",
        "2x Mastery" to "32M Val · 450 R$",
        "Fast Boats" to "18M Val · 350 R$"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Blox Fruits Gamepasses", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Store passes and their market trading values", color = TextSecondary, fontSize = 12.sp)
        }

        items(passes) { pass ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardBackground)
                    .border(1.dp, BorderDark, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(pass.first, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(pass.second, color = ProfitGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun TraderProfileScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Trader Profile & Personal ID", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceDark)
                .border(1.dp, BorderAccent, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Text("GXRV Dynasty [Owner]", color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 16.sp)
                Text("ID: GXRV-0001-K · Roblox: @GXRV_DynastyKing", color = ElectricBlue, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("100% Reputation", color = ProfitGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("542 Completed Trades", color = TextSecondary, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun TradeHistoryScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Trade History Log", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Completed trades, net profit/loss delta, and counterparties", color = TextSecondary, fontSize = 12.sp)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(CardBackground)
                .border(1.dp, ProfitGreen.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Partner: @DragonSlayer_99", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("+18M Delta", color = ProfitGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text("You Gave: Kitsune ➔ They Gave: Dark Blade + Dough + Buddha", color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun AdminPanelScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Admin & Moderator Panel", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Role-Based Access Control · Fruit Values & Dealer Stock Overrides", color = ElectricBlue, fontSize = 12.sp)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(SurfaceDark)
                .border(1.dp, BorderDark, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Staff Controls Active", color = ProfitGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("• Edit Physical & Permanent Values for all 44 fruits", color = TextSecondary, fontSize = 12.sp)
                Text("• Force Normal or Mirage dealer restock cycles", color = TextSecondary, fontSize = 12.sp)
                Text("• Review and verify pending scam reports with proof attachments", color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}
